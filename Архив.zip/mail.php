<?php

$recepient = "dardurranisc@gmail.com";
$siteName = "Serre";

$name = trim($_POST["name"]);
$email = trim($_POST["user_email"]);
$nameservice = trim($_POST["name_service"]);
$amount = trim($_POST["amount"]);
$oplata = trim($_POST["oplata"]);
$message = "Имя: $name \nПочта: $email\nНазвание услуги: $nameservice\nКол-во: $amount\nОплата через: $oplata ";

$pagetitle = "Заявка с сайта \"$siteName\"";
mail($recepient, $pagetitle, $message, "Content-type: text/plain; charset=\"utf-8\"\n From: $recepient");

?>